# 🔐 Password Strength Checker

A command-line cybersecurity tool built in **Python** that analyzes password strength using length, character composition, common-password detection, and pattern analysis — then returns a 0–100 score, a strength classification, and actionable improvement suggestions.

> Built for **DecodeLabs Cyber Security Internship — Project 1**
> Author: **Sundas Bibi**

---

## 📸 Sample Output

```
╔══════════════════════════════════════════════════════════╗
║                                                              ║
║        🔐  P A S S W O R D   S T R E N G T H   C H E C K E R  🔐     ║
║                                                              ║
║              DecodeLabs Cyber Security Internship          ║
║                     Project 1  •  by Sundas Bibi             ║
║                                                              ║
╚══════════════════════════════════════════════════════════╝

Enter password ➤ P@ssw0rd123!

================================================================
Analyzing password: ************  (masked for your privacy)
================================================================

Length: 12 characters

Character Composition:
  ✔  Uppercase Letters (A-Z)
  ✔  Lowercase Letters (a-z)
  ✔  Digits (0-9)
  ✔  Special Characters (!@#$...)

Strength Meter:
[█████████████████████████░░░░]  80/100  →  Strong

Suggestions:
  ➤ Great job! Your password meets all the recommended criteria.
================================================================
```

---

## ✨ Features

- **0–100 numeric scoring system** combining length, variety, bonuses, and penalties
- **4-tier classification**: Weak, Medium, Strong, Very Strong
- **Common password detection** against a curated list of known breached passwords (e.g. `123456`, `password`, `qwerty`)
- **Pattern detection** for repeated characters (`aaaa`) and sequential characters (`abcd`, `1234`)
- **Character composition breakdown** showing exactly which categories (uppercase, lowercase, digits, special) are present
- **Personalized improvement suggestions** generated dynamically based on what's missing
- **Colorful, modern terminal UI** using Colorama — color-coded by strength tier
- **Visual strength meter** (progress-bar style) for instant readability
- **Password masking** in output for privacy/screen-recording safety
- **Robust exception handling** — the tool never crashes on bad input, Ctrl+C, or empty strings
- **Continuous loop interface** — check multiple passwords in one session without restarting

---

## 📁 Project Folder Structure

```
PasswordStrengthChecker/
├── password_checker.py     # Main application — all logic and CLI interface
├── requirements.txt         # Python dependencies (colorama)
└── README.md                  # This file
```

---

## ⚙️ Installation & Usage

### 1. Clone or download the project
```bash
git clone https://github.com/<your-username>/CodeAlpha_PasswordStrengthChecker.git
cd PasswordStrengthChecker
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the tool
```bash
python password_checker.py
```

### 4. Using the tool
- Type any password at the prompt and press Enter to see the full analysis.
- Type `exit` or `quit` at any time to close the program.
- Press `Ctrl+C` to exit safely at any point — the tool handles this gracefully.

---

## 🧮 How Scoring Works

| Component | Points | Description |
|---|---|---|
| Length | 0–25 | Longer passwords score higher (≥16 chars = full marks) |
| Character Variety | 0–50 | 12.5 points each for uppercase, lowercase, digit, special character |
| Length Bonus | 0–15 | Extra credit for passwords ≥16 or ≥20 characters |
| Variety Bonus | 0–10 | Extra credit for using *all four* character categories |
| Pattern Penalty | −0–25 | Deducted for repeated or sequential characters |
| Common Password | Capped at 5 | Instantly capped if the password matches a known breached password |

**Strength Tiers:**

| Score Range | Classification | Color |
|---|---|---|
| 0–29 | Weak | 🔴 Red |
| 30–59 | Medium | 🟡 Yellow |
| 60–84 | Strong | 🟢 Green |
| 85–100 | Very Strong | 🔵 Cyan |

---

## 🧪 Sample Input & Output

| Input Password | Score | Classification |
|---|---|---|
| `123456` | 5/100 | Weak (common password) |
| `abcd1234` | 22/100 | Weak (sequential pattern, no variety) |
| `Password1` | ~50/100 | Medium |
| `P@ssw0rd123!` | 80/100 | Strong |
| `Tr@ub4dor&3xtraLong!` | 100/100 | Very Strong |

---

## 🛠️ Built With

- **Python 3** — core logic, regex pattern matching
- **Colorama** — cross-platform colored terminal output
- **re module** — regular expressions for character and pattern detection

---

## 🚀 Future Enhancements

- Load a much larger common-password wordlist (e.g. `rockyou.txt`) from an external file instead of a hardcoded set
- Add a GUI version using Tkinter or a web version using Flask/Streamlit
- Integrate with the **Have I Been Pwned API** to check if a password has appeared in real-world breaches
- Add password generation suggestions (auto-generate a strong alternative)
- Support batch-checking multiple passwords from a `.txt` or `.csv` file
- Add unit tests with `pytest` for each scoring function
- Add multi-language support for suggestions
- Estimate brute-force crack time based on entropy

---

## 🎓 Interview / Viva Questions & Answers

**Q1: Why did you cap common passwords at a low score instead of giving 0?**
A: A small non-zero floor (5) keeps the scoring system mathematically consistent and avoids edge cases in comparisons, while still clearly classifying it as "Weak." It also reflects that even a "common" password technically has *some* length and character properties — but practically it should never be used.

**Q2: Why use regex instead of looping through each character manually?**
A: Regular expressions are more concise, readable, and optimized for pattern matching tasks like detecting character classes (`[A-Z]`, `[0-9]`) or repeated/sequential patterns. They reduce the chance of off-by-one errors compared to manual character loops.

**Q3: How does the tool detect sequential patterns like "abcd" or "1234"?**
A: It defines a reference string of ordered characters (`"abcdefghijklmnopqrstuvwxyz0123456789"`) and checks whether any 4-character substring of the password (lowercased) appears as a substring within that reference, which would indicate an ascending sequence.

**Q4: What is entropy, and how does it relate to password strength?**
A: Entropy measures the unpredictability of a password, calculated from the size of the character pool and password length. Higher entropy means more possible combinations, making brute-force attacks harder. This project approximates entropy concepts through its length and variety scoring rather than calculating exact entropy bits — a literal entropy calculation is listed under Future Enhancements.

**Q5: Why mask the password in the output instead of printing it directly?**
A: Displaying the raw password on-screen is a security risk, especially during screen sharing, recordings, or shoulder-surfing scenarios. Masking with asterisks while still analyzing the real string in memory follows secure coding best practices.

**Q6: How does your exception handling make this tool more production-ready?**
A: The program wraps user input in a `try/except` block that specifically catches `KeyboardInterrupt` (Ctrl+C) for graceful exit, and a generic `Exception` handler to prevent unexpected crashes from malformed input, ensuring the tool remains usable and professional rather than terminating abruptly.

**Q7: How would you scale this to check thousands of passwords from a leaked database?**
A: I would refactor the core analysis functions (already modular) into an importable module, then write a separate script that reads passwords line-by-line from a file, calls `calculate_score()` and `classify_strength()` for each, and writes results to a CSV report — avoiding the interactive CLI loop entirely for batch processing.

**Q8: Why did you separate scoring logic from display logic?**
A: This follows the *separation of concerns* principle. Functions like `calculate_score()` and `check_character_variety()` return raw data, while functions like `display_strength_meter()` handle only presentation. This makes the code easier to test, reuse (e.g., in a web app), and maintain.

**Q9: What's a limitation of this tool compared to real-world password security checks?**
A: It checks against a small hardcoded list of common passwords rather than a comprehensive breach database, and it doesn't check for personal information (like names or birthdays) that users often include in passwords — both are noted under Future Enhancements.

**Q10: Why use Colorama instead of just printing plain text?**
A: Colorama provides a quick, lightweight, and cross-platform way (including Windows, which doesn't natively support ANSI codes in older terminals) to add color-coded visual feedback, which significantly improves usability — a user can recognize a "Weak" (red) vs "Strong" (green) password at a glance.

---

## 👩‍💻 Author

**Sundas Bibi**
BS Computer Science, COMSATS University Islamabad, Attock Campus
📧 sundasm348@gmail.com
🔗 [LinkedIn](https://www.linkedin.com/in/sundas-bibi-7249b8280)

---

## 📜 License

This project was created for educational purposes as part of the DecodeLabs Cyber Security Internship.
