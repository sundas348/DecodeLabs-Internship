"""
=================================================================
 Password Strength Checker
 DecodeLabs Cyber Security Internship — Project 1
 Author: Sundas Bibi
=================================================================

A command-line cybersecurity tool that analyzes password strength
based on length, character variety, and known weak-password patterns.
It assigns a numeric score (0-100), classifies the password into a
strength category, and gives actionable suggestions for improvement.
"""

import re
import sys
from colorama import init, Fore, Back, Style

# Initialize colorama so colors render correctly on Windows terminals too
init(autoreset=True)


# -----------------------------------------------------------------
# Common / breached passwords list
# -----------------------------------------------------------------
# This is a small sample of extremely common passwords found in
# real-world data breaches. In a production tool, this list would be
# loaded from a much larger file (e.g. the "rockyou.txt" wordlist).
COMMON_PASSWORDS = {
    "123456", "123456789", "qwerty", "password", "111111",
    "12345678", "abc123", "1234567", "password1", "12345",
    "iloveyou", "admin", "welcome", "monkey", "login",
    "letmein", "dragon", "sunshine", "princess", "football"
}


# -----------------------------------------------------------------
# Banner
# -----------------------------------------------------------------
def show_banner():
    """Display a professional welcome banner for the tool."""
    banner = f"""
{Fore.CYAN}{Style.BRIGHT}╔══════════════════════════════════════════════════════════╗
║                                                              ║
║        🔐  P A S S W O R D   S T R E N G T H   C H E C K E R  🔐     ║
║                                                              ║
║              DecodeLabs Cyber Security Internship          ║
║                     Project 1  •  by Sundas Bibi             ║
║                                                              ║
╚══════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""
    print(banner)


# -----------------------------------------------------------------
# Core analysis functions
# -----------------------------------------------------------------
def check_length(password):
    """
    Return a length score (0-25) based on password length.
    Longer passwords are exponentially harder to brute-force.
    """
    length = len(password)
    if length >= 16:
        return 25
    elif length >= 12:
        return 20
    elif length >= 8:
        return 12
    elif length >= 5:
        return 5
    else:
        return 0


def check_character_variety(password):
    """
    Check for the presence of four character categories:
    uppercase, lowercase, digits, and special characters.

    Returns a tuple: (variety_score, details_dict)
    details_dict tells us exactly which categories are missing,
    which we use later to build suggestions.
    """
    has_upper = bool(re.search(r"[A-Z]", password))
    has_lower = bool(re.search(r"[a-z]", password))
    has_digit = bool(re.search(r"[0-9]", password))
    has_special = bool(re.search(r"[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?~`]", password))

    details = {
        "uppercase": has_upper,
        "lowercase": has_lower,
        "digit": has_digit,
        "special": has_special,
    }

    # Each satisfied category contributes 12.5 points, max 50 points total
    variety_score = sum(details.values()) * 12.5
    return variety_score, details


def check_common_password(password):
    """
    Return True if the password (case-insensitive) matches a known
    common/breached password from our COMMON_PASSWORDS set.
    """
    return password.lower() in COMMON_PASSWORDS


def check_patterns(password):
    """
    Penalize predictable patterns such as:
    - Repeated characters (aaaa, 1111)
    - Simple sequential characters (abcd, 1234)

    Returns a penalty score (0-25) to be SUBTRACTED from the total.
    """
    penalty = 0

    # Repeated character check, e.g. "aaaa" or "1111"
    if re.search(r"(.)\1{2,}", password):
        penalty += 10

    # Sequential ascending characters, e.g. "abcd", "1234"
    sequences = "abcdefghijklmnopqrstuvwxyz0123456789"
    lowered = password.lower()
    for i in range(len(lowered) - 3):
        chunk = lowered[i:i + 4]
        if chunk in sequences:
            penalty += 15
            break

    return min(penalty, 25)  # cap penalty so score never goes negative


def calculate_score(password):
    """
    Combine all checks into a final score out of 100.

    Scoring breakdown:
      - Length:            0-25 points
      - Character variety: 0-50 points
      - Length bonus:      0-15 points (extra credit for very long passwords)
      - Variety bonus:     0-10 points (extra credit for using ALL 4 character types)
      - Pattern penalty:  -0-25 points
      - Common password:   instant cap at 5 points (regardless of other factors)
    """
    if check_common_password(password):
        # A common/breached password is dangerous no matter how "complex" it looks
        return 5

    length_score = check_length(password)
    variety_score, details = check_character_variety(password)
    pattern_penalty = check_patterns(password)

    # Bonus points reward passwords that go above and beyond the basics,
    # which is what allows a password to reach the "Very Strong" tier (85+).
    length_bonus = 15 if len(password) >= 20 else (8 if len(password) >= 16 else 0)
    variety_bonus = 10 if all(details.values()) else 0

    raw_score = length_score + variety_score + length_bonus + variety_bonus - pattern_penalty
    final_score = max(0, min(100, round(raw_score)))
    return final_score


def classify_strength(score):
    """
    Map a numeric score to a strength category and color.
    Returns (label, color)
    """
    if score < 30:
        return "Weak", Fore.RED
    elif score < 60:
        return "Medium", Fore.YELLOW
    elif score < 85:
        return "Strong", Fore.GREEN
    else:
        return "Very Strong", Fore.CYAN


def generate_suggestions(password):
    """
    Build a list of human-readable suggestions to help the user
    improve their password, based on which checks failed.
    """
    suggestions = []

    if check_common_password(password):
        suggestions.append("Avoid using well-known passwords found in data breach lists.")
        return suggestions  # no point suggesting more if it's already a known leak

    if len(password) < 12:
        suggestions.append("Use at least 12 characters for stronger protection.")

    _, details = check_character_variety(password)
    if not details["uppercase"]:
        suggestions.append("Add at least one uppercase letter (A-Z).")
    if not details["lowercase"]:
        suggestions.append("Add at least one lowercase letter (a-z).")
    if not details["digit"]:
        suggestions.append("Add at least one number (0-9).")
    if not details["special"]:
        suggestions.append("Add at least one special character (e.g. !@#$%&*).")

    if re.search(r"(.)\1{2,}", password):
        suggestions.append("Avoid repeating the same character multiple times in a row.")

    sequences = "abcdefghijklmnopqrstuvwxyz0123456789"
    lowered = password.lower()
    for i in range(len(lowered) - 3):
        if lowered[i:i + 4] in sequences:
            suggestions.append("Avoid simple sequential patterns like 'abcd' or '1234'.")
            break

    if not suggestions:
        suggestions.append("Great job! Your password meets all the recommended criteria.")

    return suggestions


# -----------------------------------------------------------------
# Visual strength meter
# -----------------------------------------------------------------
def display_strength_meter(score):
    """
    Print a visual progress-bar style meter representing the
    password score out of 100.
    """
    bar_length = 30
    filled_length = int(bar_length * score / 100)

    label, color = classify_strength(score)
    bar = "█" * filled_length + "░" * (bar_length - filled_length)

    print(f"\n{Style.BRIGHT}Strength Meter:{Style.RESET_ALL}")
    print(f"{color}[{bar}]{Style.RESET_ALL}  {score}/100  →  {color}{Style.BRIGHT}{label}{Style.RESET_ALL}")


def display_character_breakdown(password):
    """Print a breakdown table of which character types are present."""
    _, details = check_character_variety(password)

    print(f"\n{Style.BRIGHT}Character Composition:{Style.RESET_ALL}")
    labels = {
        "uppercase": "Uppercase Letters (A-Z)",
        "lowercase": "Lowercase Letters (a-z)",
        "digit": "Digits (0-9)",
        "special": "Special Characters (!@#$...)",
    }
    for key, present in details.items():
        icon = f"{Fore.GREEN}✔" if present else f"{Fore.RED}✘"
        print(f"  {icon}{Style.RESET_ALL}  {labels[key]}")


# -----------------------------------------------------------------
# Main analysis pipeline
# -----------------------------------------------------------------
def analyze_password(password):
    """
    Run the full analysis pipeline on a single password and print
    a complete, formatted report to the terminal.
    """
    print(f"\n{Fore.MAGENTA}{Style.BRIGHT}{'=' * 64}{Style.RESET_ALL}")
    print(f"{Style.BRIGHT}Analyzing password: {Style.RESET_ALL}{'*' * len(password)}  "
          f"{Fore.LIGHTBLACK_EX}(masked for your privacy){Style.RESET_ALL}")
    print(f"{Fore.MAGENTA}{Style.BRIGHT}{'=' * 64}{Style.RESET_ALL}")

    # --- Length check ---
    print(f"\n{Style.BRIGHT}Length:{Style.RESET_ALL} {len(password)} characters")

    # --- Common password check ---
    if check_common_password(password):
        print(f"{Fore.RED}{Style.BRIGHT}⚠ WARNING: This password appears in known data breach lists!{Style.RESET_ALL}")

    # --- Character breakdown ---
    display_character_breakdown(password)

    # --- Score & strength ---
    score = calculate_score(password)
    display_strength_meter(score)

    # --- Suggestions ---
    print(f"\n{Style.BRIGHT}Suggestions:{Style.RESET_ALL}")
    for suggestion in generate_suggestions(password):
        print(f"  {Fore.CYAN}➤{Style.RESET_ALL} {suggestion}")

    print(f"\n{Fore.MAGENTA}{Style.BRIGHT}{'=' * 64}{Style.RESET_ALL}\n")


# -----------------------------------------------------------------
# Entry point / CLI loop
# -----------------------------------------------------------------
def main():
    """Main program loop — handles user input and exceptions gracefully."""
    show_banner()

    print(f"{Fore.LIGHTBLACK_EX}Type a password to analyze it, or type 'exit' to quit.{Style.RESET_ALL}\n")

    while True:
        try:
            password = input(f"{Fore.CYAN}{Style.BRIGHT}Enter password ➤ {Style.RESET_ALL}")

            if password.lower() in ("exit", "quit"):
                print(f"\n{Fore.CYAN}Thank you for using Password Strength Checker. Stay secure! 🔒{Style.RESET_ALL}")
                sys.exit(0)

            if password.strip() == "":
                print(f"{Fore.RED}Password cannot be empty. Please try again.{Style.RESET_ALL}\n")
                continue

            analyze_password(password)

        except KeyboardInterrupt:
            # Gracefully handle Ctrl+C instead of an ugly traceback
            print(f"\n\n{Fore.CYAN}Program interrupted by user. Goodbye! 🔒{Style.RESET_ALL}")
            sys.exit(0)
        except Exception as error:
            # Catch-all for any unexpected error so the tool never crashes
            print(f"{Fore.RED}An unexpected error occurred: {error}{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}Please try again with a different input.{Style.RESET_ALL}\n")


if __name__ == "__main__":
    main()
